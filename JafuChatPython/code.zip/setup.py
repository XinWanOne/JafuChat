from setuptools import setup

setup(
    name='JafuChat',
    version='0.1',
    packages=[''],
    url='',
    license='apache',
    author='Jason Hoford',
    author_email='',
    description=''
)
